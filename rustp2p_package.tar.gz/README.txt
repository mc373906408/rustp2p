RustP2P测试程序使用指南
======================

1. 解压文件
   tar -xzf rustp2p_package.tar.gz

2. 设置库路径
   export LD_LIBRARY_PATH="$PWD:$LD_LIBRARY_PATH"

3. 运行服务器模式
   ./tcp_test <本地IP> <TCP端口> <UDP端口> <组代码> -s

4. 运行客户端模式
   ./tcp_test <本地IP> <TCP端口> <UDP端口> <组代码> -c <服务器地址>

5. 客户端发送消息
   连接后，输入格式: <目标IP>:<消息内容>
   消息将直接发送给目标IP

注意：
- 确保所有节点使用相同的组代码
- 所有节点的TCP和UDP端口都必须开放
