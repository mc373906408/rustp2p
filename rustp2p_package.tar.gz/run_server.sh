#!/bin/bash
# 服务器模式启动脚本

# 设置库路径
export LD_LIBRARY_PATH="$PWD:$LD_LIBRARY_PATH"

# 获取本机IP
IP=$(hostname -I | awk '{print $1}')
if [ -z "$IP" ]; then
    IP="127.0.0.1"
    echo "警告: 无法获取本机IP，使用 $IP"
fi

# 设置端口和组代码
TCP_PORT=23333
UDP_PORT=23334
GROUP_CODE=12345678

echo "启动P2P服务器节点："
echo "IP: $IP, TCP端口: $TCP_PORT, UDP端口: $UDP_PORT, 组代码: $GROUP_CODE"
echo ""

# 运行服务器
./tcp_test $IP $TCP_PORT $UDP_PORT $GROUP_CODE -s
