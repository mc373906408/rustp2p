#!/bin/bash
# 客户端模式启动脚本

# 设置库路径
export LD_LIBRARY_PATH="$PWD:$LD_LIBRARY_PATH"

# 获取本机IP
IP=$(hostname -I | awk '{print $1}')
if [ -z "$IP" ]; then
    IP="127.0.0.1"
    echo "警告: 无法获取本机IP，使用 $IP"
fi

# 设置端口和组代码
TCP_PORT=23335
UDP_PORT=23336
GROUP_CODE=12345678

# 检查是否提供了服务器地址
if [ -z "$1" ]; then
    echo "错误: 请提供服务器地址"
    echo "用法: $0 <服务器IP>:<端口>"
    echo "例如: $0 192.168.1.100:23333"
    exit 1
fi

SERVER_ADDR="$1"

echo "启动P2P客户端节点："
echo "本地IP: $IP, TCP端口: $TCP_PORT, UDP端口: $UDP_PORT, 组代码: $GROUP_CODE"
echo "连接服务器: $SERVER_ADDR"
echo ""

# 运行客户端
./tcp_test $IP $TCP_PORT $UDP_PORT $GROUP_CODE -c $SERVER_ADDR
